import './card.css';

function Card({clase, imagen, cupo, descripcion}){
  return(
    <>
      <div className='card-clases'>
        <img src={imagen} alt="" />
        <h3>{clase}</h3>
        <p>Cupo: {cupo} Alumnos</p>
        <p>{descripcion}</p>
      </div>
    </>
  )
}

export default Card;