import '../../styles/pages/home.css';
import Card from '../cards/card'

function Home(){
  return(
    <>
      <div className="container-home">
        <h1>Bienvenido a la escuela de Música</h1>

        <h2>Clases Disponibles</h2>
        <Card 
          clase='Piano'
          cupo={5}
          descripcion='Aprende a tocar el piano desde lo básico hast niveles avanzados'/>
      </div>
    </>
  )
}

export default Home;